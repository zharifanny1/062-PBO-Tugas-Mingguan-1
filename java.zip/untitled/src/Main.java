import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        int pilih; //deklarasi tipe data
        Scanner inputan = new Scanner(System.in); //deklarasi input dinamis

        System.out.println("Ini adalah program java");
        System.out.println("1. Perulangan for ");
        System.out.println("2. Perulangan While");
        System.out.println("3. perulangan do-while");
        System.out.println("4. Array 1 dimensi ");
        System.out.println("5. Array multidimensi");
        System.out.println("Masukkan pilihan anda : ");
        pilih = inputan.nextInt();

        if (pilih == 1) { //ini adalah penggunaan if else
            System.out.println("Perulangan For");
            for (int a = 1; a <= 10; a++) { //ini adalah perulangan menggunakan for
                System.out.print(a);
            }
        }

        else if (pilih == 2) {
            System.out.print("Perulangan while");
            int a = 1;
            while (a <= 10) { //ini adalah perulangan menggunakan while
                System.out.println(a);
                a++;
            }
        }

        else if(pilih==3){
            System.out.println("Perulangan do-while"); //ini adalah perulangan menggunakan do-while
            int a=11;
            do{
                System.out.println(a);
                a++;
            }while(a<=10);
            System.out.println(a);
        }

        else if(pilih==4)
        {
            System.out.println("Array 1d"); //ini adalah array 1 dimensi
            int A[] = {1,2,5,4,5};
            System.out.print(A[0]);
            System.out.print(A[1]);
            System.out.print(A[2]);
            System.out.print(A[3]);
            System.out.print(A[4]);
        }

        else if(pilih==5){
            System.out.println("Array Multidimensi"); //ini adalah array multidimensi
            int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
            int x = myNumbers[1][1];
            System.out.println(x);
        }
    }
}